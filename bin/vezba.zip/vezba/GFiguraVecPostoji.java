package vezba;

public class GFiguraVecPostoji extends Exception {

}
