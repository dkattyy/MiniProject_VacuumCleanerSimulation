package vezba;

public class GNePostojiSledecaFigura extends Exception {

}
